<?php

/*
 *  ___            __  __
 * |_ _|_ ____   _|  \/  | ___ _ __  _   _
 *  | || '_ \ \ / / |\/| |/ _ \ '_ \| | | |
 *  | || | | \ V /| |  | |  __/ | | | |_| |
 * |___|_| |_|\_/ |_|  |_|\___|_| |_|\__,_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Muqsit
 * @link http://github.com/Muqsit
 *
*/

declare(strict_types=1);

namespace king\invmenu;

use king\invmenu\inventory\InvMenuInventory;

use pocketmine\item\Item;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\network\mcpe\protocol\LoginPacket;
use pocketmine\network\mcpe\protocol\NetworkStackLatencyPacket;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\UUID;

class InvMenuEventHandler implements Listener{

	public function __construct(Plugin $plugin){
		$server = $plugin->getServer();
	}
    
    /**
	 * @param InventoryTransactionEvent $event
	 * @priority NORMAL
	 * @ignoreCancelled true
	 */
	public function onInventoryTransaction(InventoryTransactionEvent $event) : void{
		$transaction = $event->getTransaction();
		$player = $transaction->getSource();
        
		$network_stack_callbacks = [];
		foreach($transaction->getActions() as $action){
			if($action instanceof SlotChangeAction && ($inventory = $action->getInventory()) instanceof InvMenuInventory){
				$result = $inventory->handleInventoryTransaction($player, $action->getSourceItem(), $action->getTargetItem(), $action, $transaction);
				$network_stack_callback = $result->getPostTransactionCallback();
				if($network_stack_callback !== null){
					$network_stack_callbacks[] = $network_stack_callback;
				}
				if(!$result->isCancelled()){
                    if (isset(InvMenu::$players[$player->getName()])){
                    	unset(InvMenu::$players[$player->getName()]);
                    }
                } else {
                    if (isset(InvMenu::$players[$player->getName()])){
            			if (InvMenu::$players[$player->getName()] == true){
                            $player->getCursorInventory()->setItem(0, Item::get(0), true);
        					$event->setCancelled(true);
            			}
        			}
				}
			}
		}
        if (isset(InvMenu::$players[$player->getName()])){
            if (InvMenu::$players[$player->getName()] == true){
        		$player->getCursorInventory()->setItem(0, Item::get(0), true);
        		$event->setCancelled(true);
            }
        } 
	}
}