<?php

declare(strict_types=1);

/*
 * ╔══╗────╔╗╔╗──────────────────
 * ╚║║╝╔══╗║╚╝║╔═╗─╔══╗╔══╗╔═╗╔╦╗
 * ╔║║╗║║║║║╔╗║║╬╚╗║║║║║║║║║╩╣║╔╝
 * ╚══╝╚╩╩╝╚╝╚╝╚══╝╚╩╩╝╚╩╩╝╚═╝╚╝
 * ──────────────────────────────
 *
 * Script of window for PMMP
 * API: 3.9.0
 * Mcpe 1.12.0
 * Author: @ImHammer__
 * Used to generate custom window (container) in mcpe!
 */

namespace king\invmenu\inventory;

use king\invmenu\InvMenu;
use king\invmenu\transaction\InvMenuTransaction;
use king\invmenu\transaction\InvMenuTransactionResult;

use Closure;
use pocketmine\plugin\PluginBase;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\inventory\ContainerInventory;
use pocketmine\inventory\transaction\InventoryTransaction;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\nbt\NetworkLittleEndianNBTStream;
use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\scheduler\ClosureTask;
use pocketmine\block\BlockFactory;
use pocketmine\math\Vector3;
use pocketmine\block\Block;

class InvMenuInventory extends ContainerInventory
{
	/* $menu Window::create($plugin, $name, $pos, false) */
	public static function create(PluginBase $plugin, string $title, Vector3 $holder, bool $double = false) : self {
	    return new InvMenuInventory($plugin, $title, $holder, $double);
	}
	
	/** @var PluginBase **/
	public $plugin;
	/** @var string **/
	public $title;
	/** @var Vector3 **/
	public $holder;
	/** @var bool **/
	public $double;
	/** @var int **/
	public $size;
	/** @var Block[] **/
	public $realBlocks = [];
	/** @var string */
	public $categorie = "";
	/** @var Closure|null */
	protected $listener;
	/** @var Closure|null */
	protected $inventory_close_listener;
    protected array $players = [];
	
	public function __construct(PluginBase $plugin, string $title, Vector3 $holder, bool $double = false)
	{
		$holder = $holder->add(0, 3, 0)->floor();
		$this->plugin = $plugin;
		$this->title = $title;
		$this->holder = $holder;
		$this->double = $double;
		$this->size = $double === true ? 54 : 27;
		parent::__construct($holder, [], $this->size, $this->title);
	}
	
	public function onOpen(Player $player) : void
	{
		$this->sendBlockInv($player, $this->holder);
		$this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function(int $currentTick) use($player) : void {
			$this->finalOpen($player);
            InvMenu::$players[$player->getName()] = true;
        }), 10);
    }
	
	public function onClose(Player $player) : void
	{
		$this->sendRealBlock($player, $this->holder);
        if($this->inventory_close_listener !== null){
			($this->inventory_close_listener)($player, $this);
        }
		if($this->double) $this->sendRealBlock($player, $this->holder->add(1, 0, 0));
		if($player->isOnline()){
            $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function(int $currentTick) use($player) : void {
				$this->finalClose($player);
        		unset(InvMenu::$players[$player->getName()]);
			}), 1);
        }
	}
	
	public function sendBlockInv(Player $player, Vector3 $pos)
	{
		$this->sendFakeBlock($player, $pos, 54);
		if($this->double){
			$this->sendFakeBlock($player, $pos->add(1, 0, 0), 54);
			$compound = new CompoundTag("", []);
			$compound->setInt("pairx", $pos->x);
			$compound->setInt("pairz", $pos->z);
            $compound->setString("CustomName", $this->title);
			$this->sendBlockData($player, $compound, $pos->add(1, 0, 0));
		}
		unset($compound);
		$compound = new CompoundTag("", []);
		$compound->setString("CustomName", $this->title);
		$this->sendBlockData($player, $compound, $pos);
	}
	
	public function sendFakeBlock(Player $player, Vector3 $pos, int $id)
	{
		$pk = new UpdateBlockPacket();
		$pk->x = (int) $pos->getFloorX();
		$pk->y = (int) $pos->getFloorY();
		$pk->z = (int) $pos->getFloorZ();
		$pk->flags = UpdateBlockPacket::FLAG_ALL;
		$pk->blockRuntimeId = BlockFactory::toStaticRuntimeId($id);
		$player->dataPacket($pk);
	}
	
	public function sendRealBlock(Player $player, Vector3 $pos)
	{
		$block = $player->getLevel()->getBlock($pos);
		$this->sendFakeBlock($player, $pos, $block->getId());
	}
	
	public function sendBlockData(Player $player, CompoundTag $tag, Vector3 $pos)
	{
		$pk = new BlockActorDataPacket;
		$pk->x = (int) $pos->getFloorX();
		$pk->y = (int) $pos->getFloorY();
		$pk->z = (int) $pos->getFloorZ();
		$pk->namedtag = (new NetworkLittleEndianNBTStream())->write($tag);
		$player->dataPacket($pk);
	}
	
	final public function finalOpen(Player $player) : void
	{
		if($player->isOnline()){
			parent::onOpen($player);
		}
	}
	
	final public function finalClose(Player $player) : void
	{
		if($player->getWindowId($this) !== -1){
			parent::onClose($player);
		}
	}
	
	public function send(Player $player){
        
        if ($this->double !== true){
            $this->holder = $player->asVector3()->add(0, -2, 0)->floor();
            $this->sendBlockInv($player, $this->holder);
        } else {
            $this->holder = $player->asVector3()->add(1, -2, 0)->floor();
            $this->sendBlockInv($player, $this->holder);
        }
        InvMenu::$players[$player->getName()] = true;
	    $player->addWindow($this);
   
    }
	/**
	 * @return int
	 */
	public function getNetworkType() : int
	{
		return 0;
	}
	
	/**
	 * @return string
	 */
	public function getName() : string
	{
		return $this->title;
	}
    
    /**
	 * @param Closure|null $listener
	 * @return self
	 *
	 * @phpstan-param Closure(InvMenuTransaction) : InvMenuTransactionResult $listener
	 */
	public function setListener(?Closure $listener) : self{
		$this->listener = $listener;
		return $this;
	}

	/**
	 * @param Closure|null $listener
	 * @return self
	 *
	 * @phpstan-param Closure(Player, \pocketmine\inventory\Inventory) : void $listener
	 */
	public function setInventoryCloseListener(?Closure $listener) : self{
		$this->inventory_close_listener = $listener;
		return $this;
    }
    
    public function handleInventoryTransaction(Player $player, Item $out, Item $in, SlotChangeAction $action, InventoryTransaction $transaction) : InvMenuTransactionResult{
		$inv_menu_txn = new InvMenuTransaction($player, $out, $in, $action, $transaction);
		return $this->listener !== null ? ($this->listener)($inv_menu_txn) : $inv_menu_txn->continue();
    }
	
	public function setName(?string $name): self {
	    $this->title = $name;
	    return $this;
	}
	
	/**
	 * @return int
	 */
	public function getDefaultSize() : int
	{
		return $this->size;
	}
	
	public function setCategorie(string $cat)
	{
		$this->categorie = $cat;
	}
}
?>