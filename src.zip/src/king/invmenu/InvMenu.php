<?php

declare(strict_types=1);

namespace king\invmenu;

use Closure;
use InvalidStateException;
use king\invmenu\inventory\InvMenuInventory;
use king\invmenu\transaction\DeterministicInvMenuTransaction;
use king\invmenu\transaction\InvMenuTransaction;
use king\invmenu\transaction\InvMenuTransactionResult;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\inventory\transaction\InventoryTransaction;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\math\Vector3;

class InvMenu implements MenuIds{

	public static function create(string $identifier) : InvMenu{
		return new InvMenu($identifier);
	}
	
	public function createInventory(): InvMenuInventory{
	    $plugin = InvMenuHandler::getRegistrant();
        if ($this->getName() === null){
            $title = "Chest";
        } else {
            $title = $this->getName();
        }
	    $pos = new Vector3();
	    if ($this->type === MenuIds::TYPE_CHEST){
	        $double = false;
	    } elseif ($this->type === MenuIds::TYPE_DOUBLE_CHEST){
	        $double = true;
	    }
	    return new InvMenuInventory($plugin, $title, $pos, $double);
	}
	

	/**
	 * @param Closure|null $listener
	 * @return Closure
	 *
	 * @phpstan-param Closure(DeterministicInvMenuTransaction) : void $listener
	 */
	public static function readonly(?Closure $listener = null) : Closure{
		return static function(InvMenuTransaction $transaction) use($listener) : InvMenuTransactionResult{
			$result = $transaction->discard();
			if($listener !== null){
				$listener(new DeterministicInvMenuTransaction($transaction, $result));
			}
			return $result;
		};
	}

	/** @var string */
	protected $type;

	/** @var string|null */
	protected $name;

    public static array $players = [];

	/** @var InvMenuInventory */
	protected $inventory;

	public function __construct(string $type){
		$this->type = $type;
		$this->inventory = $this->createInventory();
	}

	public function getType() : string{
		return $this->type;
	}

	public function getName() : ?string{
		return $this->name;
	}

	public function setName(?string $name) : self{
		$this->inventory->title = $name;
        $this->name = $name;
		return $this;
	}

	

	public function send(Player $player, string $name = null){
        if ($name !== null){
            $this->getInventory()->setName($name);
        }
        self::$players[$player->getName()] = true;
		$this->getInventory()->send($player);
	}

	public function getInventory() : InvMenuInventory{
		return $this->inventory;
	}

	/**
	 * @internal use InvMenu::send() instead.
	 *
	 * @param Player $player
	 * @return bool
	 */
	public function sendInventory(Player $player) : bool{
		return $player->addWindow($this->getInventory()) !== -1;
	}
}
